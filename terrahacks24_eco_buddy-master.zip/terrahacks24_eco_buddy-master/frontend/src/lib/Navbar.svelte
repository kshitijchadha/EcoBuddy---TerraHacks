<div class="flex bg-neutral-800 p-4 px-0 py-0">
  <div class="flex items-center">
    <img class="w-[15%] h-auto" src="/images/eco_logo.png" alt="logo">
    <h1 class="text-4xl font-bold bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent ml-4">
      ECO BUDDY
    </h1>
  </div>
  <div class="flex items-center ml-auto space-x-4">
    <a href="#" class="text-white hover:text-green-500">Home</a>
    <a href="#" class="text-white hover:text-green-500">Login</a>
  </div>
</div>
  