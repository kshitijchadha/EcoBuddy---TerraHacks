<script>
  import CameraComponent from "../lib/CameraComponent.svelte";
</script>

<div class="my-20">
  <CameraComponent/>
</div>
